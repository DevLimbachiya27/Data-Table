import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getEmployees, saveEmployees } from "../utils/storage";

export default function AddEdit() {
  const [form, setForm] = useState({
    name: "",
    email: "",
    role: "",
    salary: "",
    photo: "",
  });

  const { id } = useParams();
  const navigate = useNavigate();

  useEffect(() => {
    if (id) {
      const emp = getEmployees().find((e) => e.id === id);
      if (emp) setForm(emp);
    }
  }, [id]);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleImage = (e) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = () => {
      setForm({ ...form, photo: reader.result });
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    let data = getEmployees();

    if (id) {
      data = data.map((emp) =>
        emp.id === id ? { ...form, salary: Number(form.salary) } : emp
      );
    } else {
      data.push({
        ...form,
        salary: Number(form.salary),
        id: Date.now().toString(),
      });
    }

    saveEmployees(data);
    navigate("/");
  };

  return (
    <div className="form-box">
      <h2>{id ? "Edit Employee" : "Add Employee"}</h2>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="name"
          placeholder="Employee Name"
          value={form.name}
          onChange={handleChange}
          required
        />

        <input
          type="email"
          name="email"
          placeholder="Email Address"
          value={form.email}
          onChange={handleChange}
          required
        />

        <input
          type="text"
          name="role"
          placeholder="Job Role"
          value={form.role}
          onChange={handleChange}
          required
        />

        <input
          type="number"
          name="salary"
          placeholder="Salary"
          value={form.salary}
          onChange={handleChange}
          required
        />

        <input type="file" accept="image/*" onChange={handleImage} />

        {form.photo && (
          <img src={form.photo} alt="Preview" className="preview" />
        )}

        <button type="submit">
          {id ? "Update Employee" : "Save Employee"}
        </button>
      </form>
    </div>
  );
}
