import { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { getEmployees, saveEmployees } from "../utils/storage";
import EmployeeTable from "../components/EmployeeTable";
import SearchFilter from "../components/SearchFilter";
import SortControls from "../components/SortControls";

export default function Home() {
  const [employees, setEmployees] = useState([]);
  const [search, setSearch] = useState("");

  useEffect(() => {
    setEmployees(getEmployees());
  }, []);

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this employee?")) {
      const updated = employees.filter((emp) => emp.id !== id);
      setEmployees(updated);
      saveEmployees(updated);
    }
  };

  const filteredEmployees = employees.filter(
    (emp) =>
      emp.name.toLowerCase().includes(search.toLowerCase()) ||
      emp.role.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="container">
      <h1>Employee Management System</h1>

      <Link to="/add" className="btn-add">
        + Add Employee
      </Link>

      <SearchFilter search={search} setSearch={setSearch} />
      <SortControls employees={employees} setEmployees={setEmployees} />

      <EmployeeTable employees={filteredEmployees} onDelete={handleDelete} />
    </div>
  );
}
