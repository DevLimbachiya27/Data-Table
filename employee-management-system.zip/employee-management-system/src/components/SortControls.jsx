export default function SortControls({ employees, setEmployees }) {
  const sortNameAZ = () => {
    const sorted = [...employees].sort((a, b) => a.name.localeCompare(b.name));
    setEmployees(sorted);
  };

  const sortNameZA = () => {
    const sorted = [...employees].sort((a, b) => b.name.localeCompare(a.name));
    setEmployees(sorted);
  };

  const sortSalaryLowHigh = () => {
    const sorted = [...employees].sort(
      (a, b) => Number(a.salary) - Number(b.salary)
    );
    setEmployees(sorted);
  };

  const sortSalaryHighLow = () => {
    const sorted = [...employees].sort(
      (a, b) => Number(b.salary) - Number(a.salary)
    );
    setEmployees(sorted);
  };

  return (
    <div className="sort">
      <button onClick={sortNameAZ}>Name A–Z</button>
      <button onClick={sortNameZA}>Name Z–A</button>
      <button onClick={sortSalaryLowHigh}>Salary Low–High</button>
      <button onClick={sortSalaryHighLow}>Salary High–Low</button>
    </div>
  );
}
