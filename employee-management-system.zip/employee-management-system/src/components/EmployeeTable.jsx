import { Link } from "react-router-dom";

export default function EmployeeTable({ employees, onDelete }) {
  if (employees.length === 0) return <p>No employees found.</p>;

  return (
    <table>
      <thead>
        <tr>
          <th>Photo</th>
          <th>Name</th>
          <th>Email</th>
          <th>Role</th>
          <th>Salary</th>
          <th>Actions</th>
        </tr>
      </thead>
      <tbody>
        {employees.map((emp) => (
          <tr key={emp.id}>
            <td>
              {emp.photo ? (
                <img src={emp.photo} alt={emp.name} className="thumb" />
              ) : (
                "No Image"
              )}
            </td>
            <td>{emp.name}</td>
            <td>{emp.email}</td>
            <td>{emp.role}</td>
            <td>₹{emp.salary}</td>
            <td>
              <Link to={`/edit/${emp.id}`} className="btn">
                Edit
              </Link>
              <button
                onClick={() => onDelete(emp.id)}
                className="btn btn-delete"
              >
                Delete
              </button>
            </td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
